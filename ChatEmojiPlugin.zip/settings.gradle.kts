rootProject.name = "ChatEmoji"
